﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroObjetos
{
    public class Perro
    {
        // Campos - Fields
        public string Raza;

        public string Tamanio;

        public int Edad;

        public string Color;

        public void Ladrar()
        {
            Console.WriteLine("Guauu");
        }
    }
}
