﻿namespace EF_CodeFirst.Modelo
{
    public class Marca : EntidadBase
    {
        public string Nombre { get; set; }
    }
}