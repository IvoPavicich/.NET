﻿namespace IntroduccionMVC.Models
{
    public class VehicleListViewModel
    {
        public List<VehicleListModel> Vehiculos { get; set; }
    }
}
