﻿namespace IntroduccionMVC.Models
{
    public class VehicleListModel
    {
        public int Id { get; set; }
        public string Dominio { get; set; }
        public int AnioFabricacion { get; set; }
    }
}
