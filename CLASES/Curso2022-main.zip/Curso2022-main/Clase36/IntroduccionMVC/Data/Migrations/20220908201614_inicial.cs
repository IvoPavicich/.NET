﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IntroduccionMVC.Data.Migrations
{
    public partial class inicial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
