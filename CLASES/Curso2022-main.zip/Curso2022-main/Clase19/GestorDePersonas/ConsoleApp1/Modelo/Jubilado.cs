﻿namespace ConsoleApp1.Modelo
{
    public class Jubilado : Persona
    {
        public int AniosDeAporte { get; set; }
        public char Categoria { get; set; }
    }
}
