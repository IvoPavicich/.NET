﻿using ConsoleApp1.Frontend;

//Gestor de personas trabajadoras (empleados, desempleados, jubilados)
//Insertar personas en una base de datos, mostrar datos de una determinada persona o
//de todas las personas.

var menuAplicacion = new MenuAplicacion();
menuAplicacion.Iniciar();