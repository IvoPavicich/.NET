﻿namespace IntroduccionMVC.Models
{
    public class VehicleModel
    {
        public int Id { get; set; }
        public string Dominio { get; set; }
        public string NumeroChasis { get; set; }
        public string Propietario { get; set; }
        public int AnioFabricacion { get; set; }
    }
}
