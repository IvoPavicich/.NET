﻿using Interfaces;

var peterParker = new HombreArania();

