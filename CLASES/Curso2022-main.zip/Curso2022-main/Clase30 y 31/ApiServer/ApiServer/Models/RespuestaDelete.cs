﻿namespace ApiServer.Models
{
    public class RespuestaDelete
    {
        public int Cantidad { get; set; }
        public bool Resultado { get; set; }
        public string Mensaje { get; set; }
    }
}
